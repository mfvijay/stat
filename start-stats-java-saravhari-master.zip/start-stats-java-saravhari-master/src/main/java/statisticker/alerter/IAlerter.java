package statisticker.alerter;

public interface IAlerter {

	public void alert();

}
