# Statistics Computer

This project uses Maven and JUnit to build and test.

[See here](https://maven.apache.org/download.cgi) for download and installation

[See here](https://maven.apache.org/guides/getting-started/) for details on starting a Maven project.

[See here](https://github.com/junit-team/junit4/wiki/Assertions) for information on JUnit

## Pass the tests

The code is not complete and doesn't even compile.
See the results of compilation and execution in the GitHub 'Actions' tab.

Recognize the intention of the code by reading the tests.
Design the return type in the code.
You may alter the test while keeping its intent.

Take care not to leave behind any compiler warnings in your solution.
